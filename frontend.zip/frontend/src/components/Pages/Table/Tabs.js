import React from 'react'

const Tabs = () => {
  return (
    <>
        
    </>
  )
}

export default Tabs